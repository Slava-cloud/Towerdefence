using UnityEngine;

public class Open : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

                if (Input.GetMouseButtonDown(0))
                {
                    RaycastHit hit;
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                    if (Physics.Raycast(ray, out hit))
                    {
                        if (hit.collider != null && hit.collider.gameObject == this.gameObject)
                        {
                            Transform rectTransform = GetComponent<Transform>();
                            rectTransform.localScale = new Vector3(1, 1, 2); 
                        }
                    }
                }
    }
}
