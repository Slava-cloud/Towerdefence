using UnityEngine;

public class Shop : MonoBehaviour
{
    public GameObject ShopPanel;
    public GameObject UpgradesPanel;
    void Start()
     {
         ShopPanel.SetActive(true);
         UpgradesPanel.SetActive(false);
     }
     public void ShowLevelPanel()
     {
         ShopPanel.SetActive(false);
         UpgradesPanel.SetActive(true);
     }
 
    public void ShowMenuPanel()
     {
         ShopPanel.SetActive(true);
         UpgradesPanel.SetActive(false);
     }

    // Update is called once per frame
    void Update()
    {
        
    }
}
